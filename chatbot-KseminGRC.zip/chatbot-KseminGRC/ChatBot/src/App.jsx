import { useState, useEffect, useRef } from 'react';
import './App.css';

function App() {
  const [question, setQuestion] = useState('');
  const [chat, setChat] = useState([]);
  const [loading, setLoading] = useState(false);
  const [connected, setConnected] = useState(false);
  const [error, setError] = useState(null);
  const [warning, setWarning] = useState(null);
  const chatEndRef = useRef(null);
  
  // Auto-scroll to bottom of chat
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chat]);

  useEffect(() => {
    // Check if Flask server is running
    fetch('http://localhost:5000/')
      .then(response => response.json())
      .then(data => {
        console.log('Server status:', data);
        setConnected(true);
        setError(null);
        if (data.warning) {
          setWarning(data.warning);
        } else {
          setWarning(null);
        }
      })
      .catch(err => {
        console.error('Server connection error:', err);
        setConnected(false);
        setError('Cannot connect to server. Make sure the Flask backend is running.');
        setWarning(null);
      });
  }, []);

  const handleChat = async (e) => {
    e.preventDefault();
    if (!question.trim() || !connected) return;
    
    setLoading(true);
    setError(null);
    setWarning(null);
    const userQuestion = question.trim();
    setChat(prev => [...prev, { role: 'user', text: userQuestion }]);
    setQuestion('');
    
    try {
      const response = await fetch('http://localhost:5000/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ query: userQuestion })
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Failed to get response from chatbot');
      }

      if (data.error) {
        throw new Error(data.error);
      }
      
      if (data.warning) {
        setWarning(data.warning);
      }
      
      setChat(prev => [...prev, { 
        role: 'bot', 
        text: data.answer,
        references: data.references || []
      }]);
    } catch (err) {
      console.error('Chat error:', err);
      setError(err.message);
      setChat(prev => [...prev, { 
        role: 'bot', 
        text: `Error: ${err.message}` 
      }]);
    }
    
    setLoading(false);
  };

  return (
    <div className="container">
      <div className="chat-header">
        <h1>PDF Knowledge Bot</h1>
        <div className="status-indicator">
          <span className={`status-dot ${connected ? 'connected' : 'disconnected'}`}></span>
          <span>{connected ? 'Connected' : 'Disconnected'}</span>
        </div>
      </div>
      
      <div className="info-box">
        {error ? (
          <div className="error">{error}</div>
        ) : warning ? (
          <div className="warning">{warning}</div>
        ) : connected ? (
          'Ask any questions about the PDF content!'
        ) : (
          'Connecting to server... Make sure to start the Flask backend (python main.py)'
        )}
      </div>
      
      <div className="chat-box">
        {chat.map((msg, idx) => (
          <div key={idx} className={msg.role === 'user' ? 'chat-user' : 'chat-bot'}>
            <div className="chat-bubble">
              <div className="chat-header">
                <span className="chat-avatar">{msg.role === 'user' ? '👤' : '🤖'}</span>
                <span className="chat-name">{msg.role === 'user' ? 'You' : 'Bot'}</span>
              </div>
              <div className="chat-content">
                {msg.text}
              </div>
              
              {/* Display references if available */}
              {msg.references && msg.references.length > 0 && (
                <div className="references-container">
                  <h4>References</h4>
                  <div className="references-list">
                    {msg.references.map((ref, index) => (
                      <div key={index} className="reference-item">
                        <div className="reference-badge">{ref.reference}</div>
                        <div className="reference-text">{ref.text}</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        ))}
        
        {loading && (
          <div className="chat-bot">
            <div className="chat-bubble">
              <div className="chat-header">
                <span className="chat-avatar">🤖</span>
                <span className="chat-name">Bot</span>
              </div>
              <div className="chat-content">
                <div className="typing-indicator">
                  <span></span>
                  <span></span>
                  <span></span>
                </div>
              </div>
            </div>
          </div>
        )}
        <div ref={chatEndRef} />
      </div>
      
      <form onSubmit={handleChat} className="chat-form">
        <input
          type="text"
          value={question}
          onChange={e => setQuestion(e.target.value)}
          placeholder={connected ? "Ask a question..." : "Waiting for server connection..."}
          disabled={loading || !connected}
          className="chat-input"
        />
        <button 
          type="submit" 
          disabled={loading || !connected || !question.trim()}
          className="chat-button"
        >
          {loading ? (
            <span className="button-loader"></span>
          ) : (
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <line x1="22" y1="2" x2="11" y2="13"></line>
              <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
            </svg>
          )}
        </button>
      </form>
    </div>
  );
}

export default App;
