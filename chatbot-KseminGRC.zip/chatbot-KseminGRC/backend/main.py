"""
main.py - Flask backend for PDF Chatbot
Handles PDF chat functionality using RAG with Mistral model.
"""

import os
import traceback
from flask import Flask, request, jsonify
from flask_cors import CORS
import pypdf
from typing import List, Dict, Any, Tuple
import numpy as np
import re
import torch
from sentence_transformers import SentenceTransformer
import faiss
from huggingface_hub import InferenceClient

# Set Hugging Face API token
os.environ["HUGGINGFACE_TOKEN"] = "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"

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Config for development
app.config['DEBUG'] = True

# Cache for embeddings to improve performance
EMBEDDINGS_CACHE = {}

# Check both possible PDF locations
PDF_PATHS = [
    os.path.join("uploaded_pdfs", "prompt_engg.pdf"),
    os.path.join("..", "uploaded_pdfs", "prompt_engg.pdf")
]

# In-memory store for data
pdf_text = ""
chat_history = []

# RAG components
embedding_model = None
inference_client = None
vector_store = None
chunks = []
chunk_size = 150  # reduced from 250
chunk_overlap = 30  # reduced from 50

def load_pdf(pdf_path: str) -> str:
    """Load PDF and extract text"""
    try:
        text = ""
        with open(pdf_path, 'rb') as file:
            reader = pypdf.PdfReader(file)
            for i, page in enumerate(reader.pages):
                page_text = page.extract_text()
                if page_text:
                    # Add page marker for reference
                    text += f"[Page {i+1}] {page_text}\n\n"
        return text
    except Exception as e:
        print(f"Error loading PDF: {str(e)}")
        return ""

def clean_text(text: str) -> str:
    """Clean the text by removing artifacts and extra whitespace"""
    # Remove excessive newlines
    text = re.sub(r'\n{3,}', '\n\n', text)
    # Remove artifacts like dates in specific format
    text = re.sub(r'\d{1,2}/\d{1,2}/\d{2,4}, \d{1,2}:\d{2} [AP]M', '', text)
    # Remove other common artifacts
    text = re.sub(r'OneNote https://onedrive\.live\.com.*', '', text)
    return text.strip()

def create_chunks(text: str) -> List[Dict[str, Any]]:
    """Split the text into chunks for embedding"""
    chunks = []
    text = clean_text(text)
    paragraphs = text.split('\n\n')
    
    current_chunk = ""
    for paragraph in paragraphs:
        paragraph = paragraph.strip()
        if not paragraph:
            continue
            
        # If adding this paragraph would exceed chunk size, save current chunk and start a new one
        if len(current_chunk) + len(paragraph) > chunk_size and current_chunk:
            # Extract page reference if available
            page_match = re.search(r'\[Page (\d+)\]', current_chunk)
            page_ref = page_match.group(0) if page_match else ""
            
            chunks.append({
                "text": current_chunk,
                "reference": page_ref,
            })
            # Start new chunk with overlap
            current_chunk = paragraph
        else:
            if current_chunk:
                current_chunk += "\n\n" + paragraph
            else:
                current_chunk = paragraph
    
    # Add the last chunk if it's not empty
    if current_chunk:
        page_match = re.search(r'\[Page (\d+)\]', current_chunk)
        page_ref = page_match.group(0) if page_match else ""
        chunks.append({
            "text": current_chunk,
            "reference": page_ref,
        })
    
    return chunks

def cache_embeddings(chunks):
    global EMBEDDINGS_CACHE
    for i, chunk in enumerate(chunks):
        if chunk["text"] not in EMBEDDINGS_CACHE:
            EMBEDDINGS_CACHE[chunk["text"]] = embedding_model.encode(chunk["text"])
    return EMBEDDINGS_CACHE

def init_rag_components():
    """Initialize the RAG components including embeddings and vector store"""
    global embedding_model, vector_store, chunks, inference_client
    
    print("Initializing RAG components...")
    
    # Initialize the embedding model with device placement
    embedding_model = SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2')
    if torch.cuda.is_available():
        embedding_model = embedding_model.to('cuda')
    
    # Initialize Inference Client
    inference_client = InferenceClient(
        model="HuggingFaceH4/zephyr-7b-beta",
        token=os.environ["HUGGINGFACE_TOKEN"]
    )
    
    # Create vector store with cached embeddings
    if chunks:
        # Cache embeddings for all chunks
        cache_embeddings(chunks)
        
        # Get embeddings for all chunks from cache
        embeddings = np.array([EMBEDDINGS_CACHE[chunk["text"]] for chunk in chunks])
        
        # Normalize embeddings
        embeddings = embeddings / np.linalg.norm(embeddings, axis=1, keepdims=True)
        
        # Create FAISS index with faster search
        dimension = embeddings.shape[1]
        vector_store = faiss.IndexFlatIP(dimension)
        vector_store.add(embeddings.astype('float32'))
        
        print(f"Vector store initialized with {len(chunks)} chunks")
    else:
        print("No chunks available to create vector store")

def init_chatbot():
    """Initialize the chatbot with existing PDF"""
    global pdf_text, chunks
    
    # Try each possible PDF path
    for pdf_path in PDF_PATHS:
        if os.path.exists(pdf_path):
            try:
                print(f"Loading PDF from: {pdf_path}")
                
                # Extract text from PDF
                pdf_text = load_pdf(pdf_path)
                if not pdf_text:
                    continue
                
                # Create chunks from the PDF text
                chunks = create_chunks(pdf_text)
                print(f"Created {len(chunks)} chunks from PDF")
                
                # Initialize RAG components
                init_rag_components()
                
                print("Chatbot initialized successfully")
                return True
            except Exception as e:
                print(f"Error initializing chatbot with {pdf_path}:")
                traceback.print_exc()
                continue
    
    print("No valid PDF found in any location")
    return False

def retrieve_relevant_chunks(query: str, top_k: int = 3) -> List[Dict[str, Any]]:  # reduced top_k from 5
    """Retrieve the most relevant chunks for a query using cached embeddings"""
    if not vector_store:
        return []
    
    # Use cached embeddings if available
    query_embedding = embedding_model.encode([query])[0]
    query_embedding = query_embedding / np.linalg.norm(query_embedding)
    
    # Search the vector store with reduced top_k for faster response
    scores, indices = vector_store.search(
        np.array([query_embedding]).astype('float32'), 
        top_k
    )
    
    # Get the relevant chunks with higher relevance threshold
    relevant_chunks = [
        {
            "text": chunks[idx]["text"],
            "reference": chunks[idx]["reference"],
            "score": float(scores[0][i])
        }
        for i, idx in enumerate(indices[0])
        if idx < len(chunks) and scores[0][i] > 0.6  # Increased threshold from 0.5
    ]
    
    return relevant_chunks

def generate_response(query: str, relevant_chunks: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Generate a response using the model based on the query and relevant chunks"""
    if not relevant_chunks:
        return {
            "answer": "I couldn't find relevant information in the document to answer your question.",
            "references": []
        }
    
    # Format the context with the relevant chunks
    context = "\n\n".join([chunk["text"] for chunk in relevant_chunks])
    
    # Prepare the prompt
    prompt = f"""<|system|>
You are a helpful assistant that provides accurate information from a document. Answer the question based on the given context only.
Be concise and factual.

Context:
{context}

<|user|>
{query}

<|assistant|>"""
    
    try:
        # Generate response
        response = inference_client.text_generation(
            prompt,
            max_new_tokens=300,
            temperature=0.1,
            top_p=0.95,
            repetition_penalty=1.1
        )
        
        # Extract references
        references = [
            {
                "text": chunk["text"][:150] + "...",  # First 150 chars for preview
                "reference": chunk["reference"],
                "score": chunk["score"]
            }
            for chunk in relevant_chunks
        ]
        
        return {
            "answer": response,
            "references": references
        }
    except Exception as e:
        print(f"Error generating response: {str(e)}")
        return {
            "answer": "I apologize, but I encountered an error while generating the response. Please try again.",
            "references": []
        }

@app.route("/chat", methods=["POST"])
def chat():
    """Endpoint to chat with the PDF content"""
    global chat_history, pdf_text
    
    if not pdf_text or not vector_store:
        print("Initializing chatbot...")
        if not init_chatbot():
            return jsonify({"error": "Failed to initialize chatbot. Please check if prompt_engg.pdf exists in the uploaded_pdfs folder."}), 500
    
    try:
        data = request.get_json()
        if not data or 'query' not in data:
            return jsonify({"error": "No query provided"}), 400

        query = data['query']
        print(f"Received query: {query}")

        # Retrieve relevant chunks
        relevant_chunks = retrieve_relevant_chunks(query)
        
        # Generate response
        response = generate_response(query, relevant_chunks)
        
        chat_history.append((query, response))
        print(f"Generated answer: {response['answer'][:100]}...")
        return jsonify(response)
    
    except Exception as e:
        print(f"Error processing chat:")
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500

@app.route("/")
def home():
    if not pdf_text and not init_chatbot():
        return jsonify({
            "message": "PDF Chatbot backend is running",
            "warning": "PDF not loaded. Please check if prompt_engg.pdf exists in the uploaded_pdfs folder."
        })
    return jsonify({"message": "PDF Chatbot backend is running"})

if __name__ == "__main__":
    # Initialize chatbot on startup
    init_chatbot()
    # Run the Flask app
    app.run(host='0.0.0.0', port=5000, debug=True)
