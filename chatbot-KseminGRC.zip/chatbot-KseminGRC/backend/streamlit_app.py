import os
import json
import streamlit as st
from langchain_community.document_loaders import PyPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import FAISS
from langchain.chains import ConversationalRetrievalChain
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.llms import HuggingFaceHub
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
from fastapi import Request
from fastapi.responses import JSONResponse

# Set Hugging Face API token
os.environ["HUGGINGFACE_API_KEY"] = "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"

# Initialize FastAPI app for handling React frontend requests
app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize session state
if "initialized" not in st.session_state:
    st.session_state.initialized = False
    st.session_state.chat_history = []
    st.session_state.vector_db = None

def init_chatbot():
    """Initialize the chatbot with the PDF"""
    pdf_path = "uploaded_pdfs/prompt_engg.pdf"
    if os.path.exists(pdf_path) and not st.session_state.initialized:
        try:
            loader = PyPDFLoader(pdf_path)
            documents = loader.load()
            splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
            docs = splitter.split_documents(documents)
            
            embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-mpnet-base-v2")
            st.session_state.vector_db = FAISS.from_documents(docs, embeddings)
            st.session_state.initialized = True
            return True
        except Exception as e:
            st.error(f"Error initializing chatbot: {str(e)}")
            return False
    return st.session_state.initialized

def process_query(query):
    """Process a chat query and return response"""
    if not st.session_state.initialized:
        return {"error": "Chatbot not initialized"}
    
    try:
        llm = HuggingFaceHub(
            repo_id="mistralai/Mistral-Small-3.1-24B-Instruct-2503",
            model_kwargs={"temperature": 0.7, "max_tokens": 512},
            huggingfacehub_api_token="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"
        )
        
        rag_chain = ConversationalRetrievalChain.from_llm(
            llm, 
            st.session_state.vector_db.as_retriever(),
            return_source_documents=True
        )
        result = rag_chain({"question": query, "chat_history": st.session_state.chat_history})
        answer = result["answer"]
        st.session_state.chat_history.append((query, answer))
        return {"answer": answer}
    except Exception as e:
        return {"error": str(e)}

# FastAPI endpoint for React frontend
@app.get("/api/query")
async def api_query(query: str):
    if not st.session_state.initialized:
        init_chatbot()
    response = process_query(query)
    if "error" in response:
        return JSONResponse(status_code=500, content=response)
    return JSONResponse(content=response)

# Initialize chatbot
init_success = init_chatbot()

# Streamlit UI
st.title("PDF Knowledge Bot (Mistral)")

if init_success:
    query = st.text_input("Ask a question about the PDF content:")
    if query:
        response = process_query(query)
        if "answer" in response:
            st.write(f"**Answer:** {response['answer']}")
        else:
            st.error(response["error"])

    # Display chat history
    if st.session_state.chat_history:
        st.write("---\n### Chat History")
        for q, a in st.session_state.chat_history:
            st.write(f"**You:** {q}")
            st.write(f"**Bot:** {a}")
            st.write("---")
else:
    st.error("Chatbot initialization failed. Please check if the PDF exists in the uploaded_pdfs folder.")